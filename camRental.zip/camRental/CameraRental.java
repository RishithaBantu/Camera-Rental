package phaseproject;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Camera {
   private String brand;
   private String model;
   private double rentalAmount;
   private boolean rented;

   public Camera(String brand, String model, double rentalAmount)
   {
       this.brand = brand;
       this.model = model;
       this.rentalAmount = rentalAmount;
       this.rented = false;
   }
   public String getBrand() 
   {
       return brand;
   }
   public String getModel() {
       return model;
   }
   public double getRentalAmount() {
       return rentalAmount;
   }
   public boolean isRented() {
       return rented;
   }
   public void setRented(boolean rented) {
       this.rented = rented;
   }
}

public class CameraRental {
	
   private List<Camera> cameraList;
   private double walletBalance;

   public CameraRental() {
       cameraList = new ArrayList<>();
       walletBalance = 0.0;

       // Example cameras
       cameraList.add(new Camera("Canon", "EOS 5D Mark IV", 50.0));
       cameraList.add(new Camera("Nikon", "D850", 60.0));
       cameraList.add(new Camera("Sony", "Alpha A7 III", 70.0));
       cameraList.add(new Camera("Fujifilm", "X-T4", 80.0));
       cameraList.add(new Camera("Panasonic", "Lumix GH5", 90.0));
       cameraList.add(new Camera("Olympus", "OM-D E-M1 Mark III", 100.0));
       cameraList.add(new Camera("Leica", "M10-P", 110.0));
       cameraList.add(new Camera("Hasselblad", "X1D II 50C", 120.0));
       cameraList.add(new Camera("Phase One", "IQ4 150MP", 130.0));

       // Mark some cameras as rented
       cameraList.get(2).setRented(true);
       cameraList.get(4).setRented(true);
       cameraList.get(6).setRented(true);
   }

   public void addCamera(String brand, String model, double rentalAmount) {
       Camera camera = new Camera(brand, model, rentalAmount);
       cameraList.add(camera);
       System.out.println("\nYOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST.");
   }

   public void removeCamera(int index) {
       if (index >= 0 && index < cameraList.size()) {
           Camera camera = cameraList.get(index);
           if (!camera.isRented()) {
               cameraList.remove(index);
               System.out.println("\nCAMERA SUCCESSFULLY REMOVED FROM THE LIST.");
           } else {
               System.out.println("\nCannot remove a rented camera. Please return the camera first.");
           }
       } else {
           System.out.println("\nInvalid camera ID.");
       }
   }

   public void displayCameraList() {
       System.out.println("\nCAMERA LIST");
       System.out.println("-----------------------------------------------------------------------");
       System.out.printf("%-6s%-10s%-15s%-10s%s\n", "ID", "BRAND", "MODEL", "PRICE", "STATUS");
       System.out.println("-----------------------------------------------------------------------");

       for (int i = 0; i < cameraList.size(); i++) {
           Camera camera = cameraList.get(i);
           System.out.printf("%-6d%-10s%-15s%-10.2f%s\n", i + 1, camera.getBrand(), camera.getModel(),
                   camera.getRentalAmount(), (camera.isRented() ? "Rented" : "Available"));
       }

       if (cameraList.isEmpty()) {
           System.out.println("\nNo cameras available.");
       }

       System.out.println("-----------------------------------------------------------------------");
   }

   public void rentCamera(int index) {
	    if (index >= 0 && index < cameraList.size()) {
	        Camera camera = cameraList.get(index);
	        if (!camera.isRented()) {
	            if (walletBalance >= camera.getRentalAmount()) {
	                camera.setRented(true);
	                walletBalance -= camera.getRentalAmount();
	                System.out.printf("\nYour transaction for camera %s %s with rent INR. %.2f has been successfully completed.\n",
	                        camera.getBrand(), camera.getModel(), camera.getRentalAmount());
	            } else {
	                System.out.println("\nInsufficient balance in your wallet. Please deposit more funds.");
	            }
	        } else {
	            System.out.println("\nThis camera is already rented. Please select another camera.");
	        }
	    } else {
	        System.out.println("\nInvalid camera ID.");
	    }
	}


   public void manageWallet() {
       Scanner scanner = new Scanner(System.in);

       System.out.println("\nMY WALLET");
       System.out.println("1. VIEW WALLET BALANCE");
       System.out.println("2. DEPOSIT TO WALLET");
       System.out.println("3. GO BACK");

       System.out.print("Enter your choice: ");
       int choice = scanner.nextInt();

       switch (choice) {
           case 1:
               System.out.printf("\nYour current wallet balance is INR %.2f\n", walletBalance);
               break;

           case 2:
               System.out.print("Enter the amount to deposit (INR): ");
               double amount = scanner.nextDouble();
               walletBalance += amount;
               System.out.printf("Your wallet balance has been updated successfully. Current wallet balance: INR %.2f\n",
                       walletBalance);
               break;

           case 3:
               // Go back to previous menu
               break;

           default:
               System.out.println("Invalid choice. Please try again.");
               break;
       }
   }

   public void startApp() {
       Scanner scanner = new Scanner(System.in);

       System.out.println("*******************************************");
       System.out.println("*      WELCOME TO CAMERA RENTAL APP       * ");
       System.out.println("*******************************************");
       System.out.println("\nPLEASE LOGIN TO CONTINUE");

       System.out.print("\nUSERNAME: ");
       String username = scanner.nextLine();

       System.out.print("PASSWORD: ");
       String password = scanner.nextLine();

       System.out.println("\nLOGIN SUCCESSFUL!");

       while (true) {
           System.out.println("\nOPTIONS:");
           System.out.println("1. MY CAMERA");
           System.out.println("2. RENT A CAMERA");
           System.out.println("3. VIEW ALL CAMERAS");
           System.out.println("4. MY WALLET");
           System.out.println("5. EXIT");

           System.out.print("Enter your choice: ");
           int option = scanner.nextInt();

           switch (option) {
               case 1:
                   System.out.println("\nMY CAMERA");
                   System.out.println("1. ADD");
                   System.out.println("2. REMOVE");
                   System.out.println("3. VIEW MY CAMERAS");
                   System.out.println("4. GO TO PREVIOUS MENU");

                   System.out.print("Enter your choice: ");
                   int cameraOption = scanner.nextInt();

                   switch (cameraOption) {
                       case 1:
                           scanner.nextLine(); // Consume the newline character

                           System.out.print("\nEnter the camera brand: ");
                           String brand = scanner.nextLine();

                           System.out.print("Enter the model: ");
                           String model = scanner.nextLine();

                           System.out.print("Enter the per day price (INR): ");
                           double rentalAmount = scanner.nextDouble();

                           addCamera(brand, model, rentalAmount);
                           break;

                       case 2:
                           System.out.print("\nEnter the ID of the camera to be removed: ");
                           int removeIndex = scanner.nextInt();
                           removeCamera(removeIndex - 1);
                           break;

                       case 3:
                           displayCameraList();
                           break;

                       case 4:
                           // Go back to previous menu
                           break;

                       default:
                           System.out.println("\nInvalid choice. Please try again.");
                           break;
                   }
                   break;

               case 2:
                   displayCameraList();
                   System.out.print("\nEnter the ID of the camera to rent: ");
                   int rentIndex = scanner.nextInt();
                   rentCamera(rentIndex - 1);
                   break;

               case 3:
                   displayCameraList();
                   break;

               case 4:
                   manageWallet();
                   break;

               case 5:
                   System.out.println("\nTHANK YOU FOR USING CAMERA RENTAL APP. GOODBYE!");
                   return;

               default:
                   System.out.println("\nInvalid choice. Please try again.");
                   break;
           }
       }
   }

   public static void main(String[] args) {
       CameraRental app = new CameraRental();
       app.startApp();
   }
}  
